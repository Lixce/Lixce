function initParallax() {
  const layers = document.querySelectorAll('.parallax-wrap [data-speed]');
  if (!layers.length) return;

  function updateParallax() {
    const scrolled = window.scrollY;
    layers.forEach(function (layer) {
      const speed = parseFloat(layer.getAttribute('data-speed')) || 0.3;
      const y = scrolled * (1 - speed) * 0.3;
      layer.style.transform = 'translate3d(0, ' + y + 'px, 0)';
    });
  }

  window.addEventListener('scroll', updateParallax, { passive: true });
  updateParallax();
}

function initReveal() {
  const items = document.querySelectorAll('.reveal');
  if (!items.length) return;

  const observer = new IntersectionObserver(
    function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('reveal--visible');
        }
      });
    },
    { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
  );

  items.forEach(function (el) {
    observer.observe(el);
  });
}

function initNavActive() {
  const path = window.location.pathname.replace(/^.*\//, '') || 'index.html';
  document.querySelectorAll('.nav__link').forEach(function (link) {
    const href = link.getAttribute('href') || '';
    link.classList.toggle('nav__link--active', href === path || (path === '' && href === 'index.html'));
  });
}

function closeModal(overlay) {
  if (!overlay) return;
  overlay.classList.remove('modal-overlay--open');
  document.body.style.overflow = '';
}

function initEpochModals() {
  const overlay = document.getElementById('modal-overlay');
  if (!overlay) return;

  function handleClose() {
    overlay.classList.remove('modal-overlay--open');
    document.body.style.overflow = '';
  }

  overlay.querySelectorAll('.modal__close').forEach(function (btn) {
    btn.addEventListener('click', handleClose);
  });
  overlay.addEventListener('click', function (e) {
    if (e.target === overlay) handleClose();
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && overlay.classList.contains('modal-overlay--open')) handleClose();
  });
}

function initFactsIntroClose() {
  const closeBtn = document.getElementById('facts-intro-close');
  const block = document.getElementById('facts-intro');
  if (closeBtn && block) {
    closeBtn.addEventListener('click', function () {
      block.style.display = 'none';
    });
  }
}

function initFactsModals() {
  const triggers = document.querySelectorAll('[data-fact-modal]');
  const overlay = document.getElementById('facts-modal-overlay');
  if (!overlay) return;

  triggers.forEach(function (btn) {
    btn.addEventListener('click', function () {
      const id = btn.getAttribute('data-fact-modal');
      const content = document.getElementById(id);
      if (content) {
        const clone = content.cloneNode(true);
        const body = overlay.querySelector('.modal__body');
        body.innerHTML = '';
        body.appendChild(clone);
        overlay.classList.add('modal-overlay--open');
        document.body.style.overflow = 'hidden';
      }
    });
  });

  function closeModal() {
    overlay.classList.remove('modal-overlay--open');
    document.body.style.overflow = '';
  }

  overlay.querySelectorAll('.modal__close').forEach(function (btn) {
    btn.addEventListener('click', closeModal);
  });
  overlay.addEventListener('click', function (e) {
    if (e.target === overlay) closeModal();
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && overlay.classList.contains('modal-overlay--open')) closeModal();
  });
}

document.addEventListener('DOMContentLoaded', function () {
  initParallax();
  initReveal();
  initNavActive();
  initEpochModals();
  initFactsIntroClose();
  initFactsModals();
});
