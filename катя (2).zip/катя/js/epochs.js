document.addEventListener('DOMContentLoaded', function () {
  const overlay = document.getElementById('modal-overlay');
  const modalImg = document.getElementById('modal-img');
  const modalBody = document.getElementById('modal-body');
  if (!overlay || !modalBody) return;

  document.querySelectorAll('[data-modal]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const id = btn.getAttribute('data-modal');
      const tpl = document.getElementById(id);
      if (!tpl || tpl.tagName !== 'TEMPLATE') return;
      var wrap = tpl.content.querySelector('.modal__img-wrap img');
      var bodyBlock = tpl.content.querySelector('.modal__body');
      if (modalImg && wrap) modalImg.src = wrap.src || '';
      if (modalImg && wrap && wrap.alt) modalImg.alt = wrap.alt;
      if (bodyBlock) modalBody.innerHTML = bodyBlock.innerHTML;
      overlay.classList.add('modal-overlay--open');
      document.body.style.overflow = 'hidden';
    });
  });
});
